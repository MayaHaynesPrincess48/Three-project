import Canvas from "./components/Canvas/Canvas";

function App() {
  return <Canvas />;
}

export default App;
